package com.vanhieu.tpms

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.graphics.*
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Chỉnh nếu số bar lệch so với app gốc (áp suất khí quyển, kPa)
const val ATM_KPA = 101

class Tire(val mac: String) {
    var bar = 0.0
    var c = 0
    var rssi = 0
    var time = 0L
}

class MainActivity : Activity() {
    // Thứ tự: 0 trước trái, 1 trước phải, 2 sau trái, 3 sau phải
    private val tires = listOf(
        Tire("50:F8:AD:23:63:B3"),
        Tire("50:F8:AD:23:5D:99"),
        Tire("50:F8:AD:23:6E:82"),
        Tire("50:F8:AD:23:86:DB")
    )
    private lateinit var view: CarView
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("tpms", MODE_PRIVATE) }
    private var scanning = false
    private var resumed = false
    private var askedPerm = false
    private var lastStart = 0L

    private val cb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            val d = r.scanRecord?.getManufacturerSpecificData(0) ?: return
            if (d.size < 12) return
            val mac = d.copyOfRange(6, 12).joinToString(":") { "%02X".format(it) }
            val t = tires.firstOrNull { it.mac == mac } ?: return
            val temp = ((d[0].toInt() and 0xFF) shl 8) or (d[1].toInt() and 0xFF)
            val kpa = ((d[2].toInt() and 0xFF) shl 8) or (d[3].toInt() and 0xFF)
            t.c = temp
            t.bar = (kpa - ATM_KPA) / 100.0
            t.rssi = r.rssi
            t.time = System.currentTimeMillis()
            prefs.edit().putString(mac, t.bar.toString() + "|" + t.c + "|" + t.rssi + "|" + t.time).apply()
            runOnUiThread { view.invalidate() }
        }

        override fun onScanFailed(errorCode: Int) {
            scanning = false
            view.setStatus("Quét lỗi (mã " + errorCode + "), đang thử lại...", true)
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = CarView.BG
        window.navigationBarColor = CarView.BG
        // Nạp lại dữ liệu lần cuối để mở app lên là có số ngay
        for (t in tires) {
            val parts = prefs.getString(t.mac, null)?.split("|") ?: continue
            if (parts.size == 4) {
                t.bar = parts[0].toDoubleOrNull() ?: 0.0
                t.c = parts[1].toIntOrNull() ?: 0
                t.rssi = parts[2].toIntOrNull() ?: 0
                t.time = parts[3].toLongOrNull() ?: 0L
            }
        }
        view = CarView(this, tires)
        setContentView(view)
        handler.post(object : Runnable {
            override fun run() { view.invalidate(); watchdog(); handler.postDelayed(this, 1000) }
        })
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        val perms = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) startScan()
        else if (!askedPerm) { askedPerm = true; requestPermissions(perms, 1) }
        else view.setStatus("Chưa được cấp quyền quét Bluetooth/Vị trí", true)
    }

    override fun onPause() {
        super.onPause()
        resumed = false
        stopScan()
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, g: IntArray) {
        if (g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED) startScan()
        else view.setStatus("Chưa được cấp quyền quét Bluetooth/Vị trí", true)
    }

    // Quét lại nếu quá 30 giây không có gói nào (tối đa 2 lần/phút, không bị Android chặn)
    private fun watchdog() {
        if (!resumed) return
        val now = System.currentTimeMillis()
        val latest = tires.maxOf { it.time }
        if (!scanning) {
            if (now - lastStart > 8000) startScan()
        } else if (now - lastStart > 30000 && now - latest > 30000) {
            startScan()
        }
    }

    private fun locationOn(): Boolean {
        if (Build.VERSION.SDK_INT >= 31) return true
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return if (Build.VERSION.SDK_INT >= 28) lm.isLocationEnabled
        else lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    private fun startScan() {
        lastStart = System.currentTimeMillis()
        stopScan()
        val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) { view.setStatus("Hãy bật Bluetooth", true); return }
        if (!locationOn()) { view.setStatus("Hãy bật Vị trí (GPS) của điện thoại", true); return }
        val scanner = adapter.bluetoothLeScanner
        if (scanner == null) { view.setStatus("Bluetooth chưa sẵn sàng", true); return }
        try {
            val st = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
            scanner.startScan(null, st, cb)
            scanning = true
            view.setStatus("Đang quét cảm biến...", false)
        } catch (e: Exception) {
            view.setStatus("Không quét được: " + e.message, true)
        }
    }

    private fun stopScan() {
        if (!scanning) return
        try {
            (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter.bluetoothLeScanner.stopScan(cb)
        } catch (_: Exception) {}
        scanning = false
    }
}

class CarView(ctx: Context, private val tires: List<Tire>) : View(ctx) {
    companion object { const val BG = 0xFF33383D.toInt() }

    private var status = ""
    private var statusError = false
    fun setStatus(s: String, err: Boolean) { status = s; statusError = err; postInvalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

    private fun stateColor(t: Tire): Int {
        val age = System.currentTimeMillis() - t.time
        return when {
            t.time == 0L || age > 120_000 -> 0xFF6B7278.toInt()
            t.bar < 2.0 || t.bar > 3.2 -> 0xFFFF4D4F.toInt()
            t.bar < 2.2 || t.bar > 3.0 -> 0xFFFFA940.toInt()
            else -> 0xFF07D36B.toInt()
        }
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
                     align: Paint.Align, bold: Boolean = false) {
        tp.textSize = size; tp.color = color; tp.textAlign = align
        tp.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        c.drawText(s, x, y, tp)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val k = w / 1186f
        c.drawColor(BG)
        text(c, "Áp suất lốp", 40f * k, h * 0.07f, 54f * k, 0xFFFFFFFF.toInt(), Paint.Align.LEFT, true)

        val cx = w / 2
        val carW = w * 0.31f
        val carH = carW * 2.6f
        val top = h * 0.5f - carH / 2
        val bot = top + carH
        val l = cx - carW / 2
        val r = cx + carW / 2
        val wheelW = carW * 0.09f
        val wheelH = carH * 0.14f
        val rowY = floatArrayOf(top + carH * 0.23f, top + carH * 0.72f)

        // Bánh xe (vẽ trước thân xe)
        for (i in 0..3) {
            val left = i % 2 == 0
            val wy = rowY[i / 2]
            val ov = carW * 0.012f
            val rect = if (left) RectF(l - wheelW + ov, wy - wheelH / 2, l + ov, wy + wheelH / 2)
            else RectF(r - ov, wy - wheelH / 2, r + wheelW - ov, wy + wheelH / 2)
            p.style = Paint.Style.FILL
            p.color = stateColor(tires[i])
            c.drawRoundRect(rect, wheelW * 0.4f, wheelW * 0.4f, p)
        }

        // Thân xe
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, top, 0f, bot,
            intArrayOf(0xFF3A3A3D.toInt(), 0xFF151517.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(l, top, r, bot), carW * 0.40f, carW * 0.40f, p)
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f * k; p.color = 0x33FFFFFF
        c.drawRoundRect(RectF(l, top, r, bot), carW * 0.40f, carW * 0.40f, p)
        p.style = Paint.Style.FILL

        fun trap(y0: Float, y1: Float, in0: Float, in1: Float) {
            path.reset()
            path.moveTo(l + in0, y0); path.lineTo(r - in0, y0)
            path.lineTo(r - in1, y1); path.lineTo(l + in1, y1); path.close()
        }
        p.color = 0xFF0A0A0B.toInt()
        trap(top + carH * 0.25f, top + carH * 0.37f, carW * 0.17f, carW * 0.08f)
        c.drawPath(path, p)
        trap(top + carH * 0.66f, top + carH * 0.78f, carW * 0.08f, carW * 0.17f)
        c.drawPath(path, p)
        p.color = 0xFF202022.toInt()
        c.drawRoundRect(RectF(l + carW * 0.08f, top + carH * 0.37f, r - carW * 0.08f, top + carH * 0.66f),
            carW * 0.12f, carW * 0.12f, p)
        // Gương
        p.color = 0xFF9AA0A6.toInt()
        c.drawOval(RectF(l - carW * 0.07f, top + carH * 0.345f, l + carW * 0.05f, top + carH * 0.39f), p)
        c.drawOval(RectF(r - carW * 0.05f, top + carH * 0.345f, r + carW * 0.07f, top + carH * 0.39f), p)
        // Đèn trước / sau
        p.color = 0x99FFFFFF.toInt()
        c.drawRoundRect(RectF(l + carW * 0.08f, top + carH * 0.025f, l + carW * 0.28f, top + carH * 0.05f), 8f * k, 8f * k, p)
        c.drawRoundRect(RectF(r - carW * 0.28f, top + carH * 0.025f, r - carW * 0.08f, top + carH * 0.05f), 8f * k, 8f * k, p)
        p.color = 0xFFCC2222.toInt()
        c.drawRoundRect(RectF(l + carW * 0.08f, bot - carH * 0.05f, l + carW * 0.28f, bot - carH * 0.03f), 8f * k, 8f * k, p)
        c.drawRoundRect(RectF(r - carW * 0.28f, bot - carH * 0.05f, r - carW * 0.08f, bot - carH * 0.03f), 8f * k, 8f * k, p)

        // Thông số từng lốp
        val now = System.currentTimeMillis()
        for (i in 0..3) {
            val t = tires[i]
            val left = i % 2 == 0
            val wy = rowY[i / 2]
            val col = stateColor(t)
            val has = t.time != 0L
            val arcR = w * 0.085f
            val arcEdge = if (left) w * 0.22f else w - w * 0.22f
            val ringX = if (left) l - wheelW - 18f * k else r + wheelW + 18f * k
            val ringR = 13f * k

            // Cung + đường nối + vòng tròn
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f * k
            p.color = (col and 0x00FFFFFF) or 0xAA000000.toInt()
            if (left) c.drawArc(RectF(arcEdge - 2 * arcR, wy - arcR, arcEdge, wy + arcR), -90f, 180f, false, p)
            else c.drawArc(RectF(arcEdge, wy - arcR, arcEdge + 2 * arcR, wy + arcR), 90f, 180f, false, p)
            c.drawLine(arcEdge, wy, if (left) ringX - ringR else ringX + ringR, wy, p)
            p.color = col; p.strokeWidth = 5f * k
            c.drawCircle(ringX, wy, ringR, p)
            p.style = Paint.Style.FILL

            val colX = if (left) 83f * k else w - 83f * k
            val macX = if (left) 28f * k else w - 28f * k
            val al = if (left) Paint.Align.LEFT else Paint.Align.RIGHT
            val barS = if (has) String.format(Locale.US, "%.1f", t.bar) else "--"
            val tempS = if (has) t.c.toString() + "°C" else "--°C"
            text(c, barS, colX, wy - 45f * k, 58f * k, 0xFFFFFFFF.toInt(), Paint.Align.CENTER, true)
            text(c, "Bar", colX, wy + 5f * k, 38f * k, 0xFF9AA0A6.toInt(), Paint.Align.CENTER, true)
            text(c, tempS, colX, wy + 73f * k, 44f * k, 0xFFFFFFFF.toInt(), Paint.Align.CENTER, true)
            text(c, t.mac.lowercase(Locale.US), macX, wy + 130f * k, 31f * k, 0xFFE8EAED.toInt(), al)
            val ageS = (now - t.time) / 1000
            val st = when {
                !has -> "Đang chờ tín hiệu..."
                ageS < 120 -> String.format(Locale.US, "%d dBm • %ds", t.rssi, ageS)
                ageS < 7200 -> "Dữ liệu cũ • " + (ageS / 60) + " phút"
                else -> "Dữ liệu cũ • " + (ageS / 3600) + " giờ"
            }
            text(c, st, macX, wy + 176f * k, 31f * k, 0xFF9AA0A6.toInt(), al)
        }

        val latest = tires.maxOf { it.time }
        val foot = if (latest == 0L) "Chưa có dữ liệu"
        else "Dữ liệu cập nhật ngày " + fmt.format(Date(latest))
        text(c, foot, cx, h * 0.935f, 40f * k, 0xFF8A9096.toInt(), Paint.Align.CENTER)
        if (status.isNotEmpty()) text(c, status, cx, h * 0.965f, 32f * k,
            if (statusError) 0xFFFFA940.toInt() else 0xFF6B7278.toInt(), Paint.Align.CENTER)
    }
}
