package com.vanhieu.tpms

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    data class Reading(val id: String, val bar: Double, val c: Int, val rssi: Int, val time: Long)

    private val readings = HashMap<String, Reading>()
    private val names = listOf("Trước trái", "Trước phải", "Sau trái", "Sau phải")
    private val prefs by lazy { getSharedPreferences("tpms", MODE_PRIVATE) }
    private lateinit var cards: List<TextView>
    private lateinit var info: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var scanning = false

    private val cb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            // Company ID 0x0000, payload 12 byte: [temp°C][kPa tuyệt đối][?][ID 4 byte][checksum]
            val d = r.scanRecord?.getManufacturerSpecificData(0) ?: return
            if (d.size < 10) return
            val temp = ((d[0].toInt() and 0xFF) shl 8) or (d[1].toInt() and 0xFF)
            val kpa = ((d[2].toInt() and 0xFF) shl 8) or (d[3].toInt() and 0xFF)
            val id = d.copyOfRange(6, 10).joinToString("") { "%02X".format(it) }
            readings[id] = Reading(id, (kpa - 101) / 100.0, temp, r.rssi, System.currentTimeMillis())
            runOnUiThread { refresh() }
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        cards = names.indices.map { i ->
            TextView(this).apply {
                textSize = 22f
                setPadding(32, 32, 32, 32)
                setBackgroundColor(0xFFEEEEEE.toInt())
                gravity = Gravity.START
                setOnClickListener { pick(i) }
                root.addView(this, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 24 })
            }
        }
        info = TextView(this).apply { textSize = 14f }
        root.addView(info)
        setContentView(root)
        refresh()
        handler.post(object : Runnable {
            override fun run() { refresh(); handler.postDelayed(this, 2000) }
        })
        val perms = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) startScan()
        else requestPermissions(perms, 1)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, g: IntArray) {
        if (g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED) startScan()
        else info.text = "Cần cấp quyền Bluetooth để quét."
    }

    private fun startScan() {
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) { info.text = "Hãy bật Bluetooth."; return }
        adapter.bluetoothLeScanner.startScan(cb)
        scanning = true
    }

    override fun onDestroy() {
        super.onDestroy()
        if (scanning) try {
            (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter.bluetoothLeScanner.stopScan(cb)
        } catch (_: Exception) {}
    }

    private fun pick(i: Int) {
        val ids = readings.keys.sorted()
        val items = (ids.map { "$it  (${"%.2f".format(readings[it]!!.bar)} bar)" } + "Bỏ gán").toTypedArray()
        AlertDialog.Builder(this).setTitle("Gán cảm biến cho ${names[i]}")
            .setItems(items) { _, w ->
                if (w < ids.size) prefs.edit().putString("pos$i", ids[w]).apply()
                else prefs.edit().remove("pos$i").apply()
                refresh()
            }.show()
    }

    private fun refresh() {
        val now = System.currentTimeMillis()
        names.forEachIndexed { i, n ->
            val id = prefs.getString("pos$i", null)
            val r = id?.let { readings[it] }
            cards[i].text = when {
                id == null -> "$n\nChạm để gán cảm biến"
                r == null -> "$n  [$id]\nĐang chờ tín hiệu..."
                else -> {
                    val age = (now - r.time) / 1000
                    "$n  [$id]\n%.2f bar   %d°C\nRSSI %d dBm  •  %ds trước".format(r.bar, r.c, r.rssi, age)
                }
            }
            cards[i].setTextColor(if (r != null && now - r.time > 60000) 0xFF999999.toInt() else 0xFF000000.toInt())
        }
        info.text = "Cảm biến phát hiện: " + readings.keys.sorted().joinToString(", ").ifEmpty { "chưa có" }
    }
}
